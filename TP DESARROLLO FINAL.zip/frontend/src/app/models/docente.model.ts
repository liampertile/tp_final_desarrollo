export interface Docente {
    id: number;       // ID del docente
    nombre: string;   // Nombre del docente
    legajo: number;   // Legajo del docente
  }
  