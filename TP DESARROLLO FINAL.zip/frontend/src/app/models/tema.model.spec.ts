import { Tema } from './tema.model';

describe('Tema', () => {
  it('should create an instance', () => {
    expect(new Tema()).toBeTruthy();
  });
});
