import { Docente } from './docente.model';

describe('Docente', () => {
  it('should create an instance', () => {
    expect(new Docente()).toBeTruthy();
  });
});
