export interface Alumno {
    id: number;             // ID del alumno, tipo número
    nombre: string;        // Nombre del alumno, tipo cadena
    fechaNacimiento: string; // Fecha de nacimiento como cadena, formato 'yyyy-MM-dd'
  }
  