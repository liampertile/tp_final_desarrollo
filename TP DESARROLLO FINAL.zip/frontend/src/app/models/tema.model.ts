export interface Tema {
    id: number;         // ID del tema
    nombre: string;     // Nombre del tema
    descripcion: string; // Descripción del tema
  }
  