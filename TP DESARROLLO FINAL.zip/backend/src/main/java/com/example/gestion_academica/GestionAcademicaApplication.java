package com.example.gestion_academica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionAcademicaApplication {
	//accion que va a levantar mi proyecto
	public static void main(String[] args) {
		SpringApplication.run(GestionAcademicaApplication.class, args);
	}

}
