package com.example.gestion_academica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestion_academica.entity.Docente;

public interface DocenteRepository extends JpaRepository<Docente, Long>{

}
